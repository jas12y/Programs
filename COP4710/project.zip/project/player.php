<?php 
	if(isset($_GET['pfile']))
		$pfile=$_GET['pfile'];
?>

<html>
<body bgcolor="#808080">
<center>
<audio controls autoplay>
<source src="<?php echo '/music/'.$pfile;?>" type="audio/mpeg">
<embed height="10" width="20" src="<?php echo '/music/'.$pfile;?>">
</audio>
</center>
</body>
</html>