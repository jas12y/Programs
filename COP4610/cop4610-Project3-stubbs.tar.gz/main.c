#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <pthread.h>
#include <semaphore.h>
#include "buffer.h"

#define RAND_DIVISOR 100000000
#define TRUE 1
#define FALSE 0

int sig_flag = TRUE;
// The mutex lock
pthread_mutex_t mutex;
// the semaphores
sem_t full, empty;
// the buffer
buffer_item buffer[BUFFER_SIZE];
// buffer counter
int counter;
//Thread ID
pthread_t tid1, tid2;
//Set of thread attributes
pthread_attr_t attr;
//Signal handler
void sig_handler(int signo)
{
   sig_flag = FALSE;
   printf("\nreceived SIGINT\n");
}
void initializeData()
{
   // Create the mutex lock
   pthread_mutex_init(&mutex, NULL);
   // Create the full semaphore and initialize to 0
   sem_init(&full, 0, 0);
   // Create the empty semaphore and initialize to BUFFER_SIZE
   sem_init(&empty, 0, BUFFER_SIZE);
   // Get the default attributes
   pthread_attr_init(&attr);
   // init buffer
   counter = 0;
}
// Producer Thread
void *producer(void *param)
{
   buffer_item item;

   while(sig_flag)
   {
      /* sleep for a random period of time */
      int rNum = rand() / RAND_DIVISOR;
      sleep(rNum);
      /* generate a random number */
      item = rand();
      /* acquire the empty lock */
      sem_wait(&empty);
      /* acquire the mutex lock */
      pthread_mutex_lock(&mutex);

      if(insert_item(item))
      {
         fprintf(stderr, "Producer report error condition\n");
      }
      else
      {
         printf("producer produced %d\n", item);
      }
      /* release the mutex lock */
      pthread_mutex_unlock(&mutex);
      /* signal full */
      sem_post(&full);
   }
}
/* Consumer Thread */
void *consumer(void *param)
{
   buffer_item item;

   while(sig_flag)
   {
      /* sleep for a random period of time */
      int rNum = rand() / RAND_DIVISOR;
      sleep(rNum);
      /* aquire the full lock */
      sem_wait(&full);
      /* aquire the mutex lock */
      pthread_mutex_lock(&mutex);
      if(remove_item(&item))
      {
         fprintf(stderr, "Consumer report error condition\n");
      }
      else
      {
         printf("consumer consumed %d\n", item);
      }
      /* release the mutex lock */
      pthread_mutex_unlock(&mutex);
      /* signal empty */
      sem_post(&empty);
   }
}
/* insert item into buffer */
int insert_item(buffer_item item)
{
   if(counter < BUFFER_SIZE)
   {
      buffer[counter] = item;
      counter++;
      return 0;
   }
   else
   {
      return -1;
   }
}
/* remove an item from the buffer */
int remove_item(buffer_item *item)
{
   if(counter > 0)
   {
      *item = buffer[(counter-1)];
      counter--;
      return 0;
   }
   else
   {
      return -1;
   }
}
int main(int argc, char *argv[])
{
   signal(SIGINT, sig_handler);
   /* Loop counter */
   int i;

   /* Verify the correct number of arguments were passed in */
   if(argc != 4)
   {
      fprintf(stderr, "USAGE:./a.out <INT> <INT> <INT>\n");
   }

   int mainSleepTime = atoi(argv[1]); /* Time in seconds for main to sleep */
   int numProd = atoi(argv[2]); /* Number of producer threads */
   int numCons = atoi(argv[3]); /* Number of consumer threads */

   /* Initialize the app */
   initializeData();

   /* Create the producer threads */
   for(i = 0; i < numProd; i++)
   {
      /* Create the thread */
      pthread_create(&tid1, &attr, producer, NULL);
   }

   /* Create the consumer threads */
   for(i = 0; i < numCons; i++)
   {
      /* Create the thread */
      pthread_create(&tid2, &attr, consumer, NULL);
   }
   /* Sleep for the specified amount of time in milliseconds */
   sleep(mainSleepTime);

   if(!sig_flag)
   {
      pthread_join(tid1, NULL);
      pthread_join(tid2, NULL);
   }

   /* Exit the program */
   printf("Exit the program\n");
   exit(0);
}
