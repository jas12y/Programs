#include <stdlib.h>
#include <stdio.h>

#define TLB_SIZE 16
#define PTABLE_SIZE 256
#define PAGE_SIZE 256
#define MAX_DATA 12

int tlb[TLB_SIZE][3];
int pagetable[PTABLE_SIZE];
int physicalmem[256][256];
int hits, faults, counter, pmcounter;

void Initialize()
{
   int i,j;

   for (i = 0; i < TLB_SIZE; i++)
   {
      for (j = 0; j < 2; j++ )
      {
         tlb[i][j] = -1;
      }
   }
   for (i = 0; i < PTABLE_SIZE; i++)
   {
   pagetable[i] = -1;
   }
   counter = 0;
   pmcounter = 0;
   hits = 0;
   faults = 0;
}
//find in tlb
int tlb_lookup(int page)
{
   int i;
   for(i = 0; i < TLB_SIZE; i++)
   {
      if(tlb[i][0] == page)
      {
         tlb[i][2] = counter; 
         return tlb[i][1];
      }	
   }
   return -1;
}
//add page to tlb
int tlb_add(int page,int frame)
{
   int i;
   //check for empty space
   for(i = 0; i < TLB_SIZE; i++)
   {
      if(tlb[i][0] == -1)
      { 
         tlb[i][0] = page;
         tlb[i][1] = frame;
         tlb[i][2] = counter;
         return 1;
      }
   }
   //find least recently used and replace
   int min = tlb[0][2];
   int temp = 0;

   for(i = 1; i < TLB_SIZE; i++)
   {
      if(tlb[i][2] < min)
      {
         min = tlb[i][2];
         temp = i;
      }
   }
   tlb[temp][0] = page;
   tlb[temp][1] = frame;
   tlb[temp][2] = counter;
   return 1;
}
//find in pagetable
int pagetable_lookup(int page)
{
   //add to tlb
   if(pagetable[page] >= 0)
   {
      tlb_add(page, pagetable[page]);
      return 1;
   }
   //page fault
   else
   {
      faults++;
      //load page into physical memory
      load_page(page, pmcounter);
      //add to pagetable
      pagetable[page] = pmcounter;
      //add to tlb
      tlb_add(page, pmcounter);
      pmcounter++;
   }		
   return -1;
}
//load page into physical memory
int load_page(int page, int frame)
{
   FILE *file;
   char buffer[PAGE_SIZE];
   int offset = page * PAGE_SIZE;
   int i;

   file = fopen("BACKING_STORE.bin", "r");

   if (file == NULL)
   {
      fprintf(stderr, "Can't open file!\n");
      exit(0);
   }

   fseek(file, offset, SEEK_SET);
   fread(buffer, 1, PAGE_SIZE, file);
   for(i = 0; i < PAGE_SIZE; i++)
   {
      physicalmem[frame][i] = buffer[i];
   }
   fclose(file);
   return 1;
}

int main(int argc, char *argv[])
{
   /* Verify the correct number of arguments were passed in */
   if(argc != 2)
   {
      fprintf(stderr, "USAGE:./a.out <FILENAME>\n");
      exit(0);
   }

   FILE *ifile;
   char *filename = argv[1];
   char input[MAX_DATA];
   int data, page, offset, frame, value, padd;

   ifile = fopen(filename, "r");

   if (ifile == NULL)
   {
      fprintf(stderr, "Can't open file!\n");
      exit(0);
   }

   Initialize();

   while ( fgets(input, sizeof input, ifile) != NULL )
   {
      data = atoi(input);
      page = data / PAGE_SIZE;
      offset = data % PAGE_SIZE;
      frame = tlb_lookup(page);
      //hit
      if (frame >= 0)
      {
         hits++;
      }
      //miss
      else if (frame == -1)
      {
         //find in pagetable
         pagetable_lookup(page);
         frame = tlb_lookup(page);
      }
      value = physicalmem[frame][offset];
      padd = frame * PAGE_SIZE + offset;
      printf("Virtual address: %d Physical address: %d Value: %d\n", data, padd, value);
      counter++;
   }

   printf("Page Fault Rate = %.2f%%\n", ((float)faults/counter) * 100);
   printf("TLB Hit Rate = %.2f%%\n", ((float)hits/counter) * 100);

   return 1;
}
