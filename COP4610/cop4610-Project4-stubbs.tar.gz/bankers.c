#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <pthread.h>

#define RAND_DIVISOR 100000000
#define TRUE 1
#define FALSE 0

/* these may be any values >= 0 */
#define NUMBER_OF_CUSTOMERS 5
#define NUMBER_OF_RESOURCES 3

// The mutex lock
pthread_mutex_t mutex;

//Thread ID
pthread_t tid;

//Set of thread attributes
pthread_attr_t attr;

/* the available amount of each resource */
int available[NUMBER_OF_RESOURCES];

/*the maximum demand of each customer */
int maximum[NUMBER_OF_CUSTOMERS][NUMBER_OF_RESOURCES];

/* the amount currently allocated to each customer */
int allocation[NUMBER_OF_CUSTOMERS][NUMBER_OF_RESOURCES];

/* the remaining need of each customer */
int need[NUMBER_OF_CUSTOMERS][NUMBER_OF_RESOURCES];

/* thread finished or not */
int finish[NUMBER_OF_CUSTOMERS];

int done = 0;

void initializeData()
{
   /* Loop counters */
   int n, m;

   // Initialize matrices to zero
   for(n = 0; n < NUMBER_OF_CUSTOMERS; n++)
   {
      for(m = 0; m < NUMBER_OF_RESOURCES; m++)
      {
         maximum[n][m] = 0;
         allocation[n][m] = 0;
         need[n][m] = 0;
      }
      finish[n] = TRUE;
   }

   // Create the mutex lock
   pthread_mutex_init(&mutex, NULL);
   // Get the default attributes
   pthread_attr_init(&attr);
}

void *customer(void *data)
{
   int request[NUMBER_OF_RESOURCES];
   int i, temp, counter = 0;
   int param = (intptr_t)data;

   /* generate random numbers for max */
   for(i = 0; i < NUMBER_OF_RESOURCES; i++)
   {
      maximum[param][i] = rand() % (available[i] + 1);
   }

   finish[param] = FALSE;

   while(!finish[param])
   {
      if((available[0] == 0 && available[1] == 0 && available[2] == 0) || counter == 2)
      {
         release_resources(param, request);
         counter = 0;
      }
      /* calculate numbers for need */
      for(i = 0; i < NUMBER_OF_RESOURCES; i++)
      {
         need[param][i] = maximum[param][i] - allocation[param][i];
      }
      /* sleep for a random period of time */
      int rNum = rand() % 3 + 1;// RAND_DIVISOR;
      sleep(rNum);
      /* acquire the mutex lock */
      pthread_mutex_lock(&mutex);

      /* generate random numbers for request */
      do
      {
         for(i = 0; i < NUMBER_OF_RESOURCES; i++)
         {
            request[i] = rand() % (need[param][i] + 1);
         }
      }while(request[0] == 0 && request[1] == 0 && request[2] == 0);
      for(i = 0; i < NUMBER_OF_RESOURCES; i++)
      {
         printf("%d ",request[i]);
      }
      /* accept or deny */
      if(request_resources(param, request) == 0)
      {
         printf(": accept\n");
         for(i = 0; i < NUMBER_OF_RESOURCES; i++)
         {
            available[i] = available[i] - request[i];
            need[param][i] = need[param][i] - request[i];
            allocation[param][i] = allocation[param][i] + request[i];
         }
      }
      else
      {
         printf(": deny\n");
         counter++;
      }
      /* release the mutex lock */
      pthread_mutex_unlock(&mutex);
      temp = TRUE;
      for(i = 0; i < NUMBER_OF_RESOURCES; i++)
      {
         if(need[param][i] > 0)
         {
            temp = FALSE;
         }
      }
      if(temp)
      {
         if(release_resources(param, request) == 0)
         {
            finish[param] = TRUE;
         }
      }
   }
   done++;
}

int request_resources(int customer_num, int request[])
{
   int j, i, n, m, x, temp;
   int work[NUMBER_OF_RESOURCES];
   int canFinish[NUMBER_OF_CUSTOMERS];
   for(n = 0; n < NUMBER_OF_CUSTOMERS; n++)
   {
      canFinish[n] = FALSE;
   }
   /* see if request is less than available */
   for(i = 0; i < NUMBER_OF_RESOURCES; i++)
   {
      if(request[i] > available[i])
      {
         return -1;
      }
      work[i] = available[i] - request[i];
   }
   for(i = 0; i < NUMBER_OF_RESOURCES; i++)
   {
      need[customer_num][i] = need[customer_num][i] - request[i];
   }
   /* see if all customers can finish */
   for(j = 0; j < NUMBER_OF_CUSTOMERS; j++)
   {
      for(n = 0; n < NUMBER_OF_CUSTOMERS; n++)
      {
         if(!canFinish[n])
         {
            temp = TRUE;
            for(m = 0; m < NUMBER_OF_RESOURCES; m++)
            {
               if(need[n][m] > work[i])
               {
                  temp = FALSE;
               }
            }
            if(temp)
            {
               canFinish[n] = TRUE;
               for(x = 0; x < NUMBER_OF_RESOURCES; x++)
               {
                  work[x] = work[x] + allocation[n][x];
               }
            }
         }
      }
   }
   for(i = 0; i < NUMBER_OF_RESOURCES; i++)
   {
      need[customer_num][i] = need[customer_num][i] + request[i];
   }
   for(j = 0; j < NUMBER_OF_CUSTOMERS; j++)
   {
      if(!canFinish[n])
      {
         return -1;
      }
   }
   return 0;
}

int release_resources(int customer_num, int release[])
{
   /* Loop counters */
   int i;

   for(i = 0; i < NUMBER_OF_RESOURCES; i++)
   {
      available[i] = available[i] + allocation[customer_num][i];
      allocation[customer_num][i] = 0;
      need[customer_num][i] = 0;
   }
   return 0;
}

int main(int argc, char *argv[])
{
   /* Loop counter */
   int i;
   srand(255);
   /* Verify the correct number of arguments were passed in */
   if(argc != 4)
   {
      fprintf(stderr, "USAGE:./a.out <INT> <INT> <INT>\n");
   }

   for(i = 1; i < 4; i++)
   {
      /* Number of resource per type */
      available[i-1] = atoi(argv[i]);
   }

   /* Initialize the app */
   initializeData();

   /* Create the threads */
   for(i = 0; i < NUMBER_OF_CUSTOMERS; i++)
   {
      /* Create the thread */
      pthread_create(&tid, &attr, customer, (void*)(intptr_t)i);
   }
   for(i = 0; i < 100; i++)
   {
      if(done == NUMBER_OF_CUSTOMERS)
         break;
      sleep(1);
   }

   exit(0);
}
