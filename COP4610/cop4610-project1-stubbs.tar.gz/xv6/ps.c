#include "types.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  static char *states[] = {
  [0]    "UNUSED",
  [1]    "EMBRYO",
  [2]    "SLEEP ",
  [3]    "RUNBLE",
  [4]    "RUN   ",
  [5]    "ZOMBIE"
  };

  int max = 64;
  struct uproc tbl[max];
  int num = getprocs(max, tbl);
  int i;
  for(i = 0; i < num; ++i)
  {
    printf(0, "%d  %d  %s  %d  %s\n",tbl[i].pid, tbl[i].ppid, states[tbl[i].state], tbl[i].sz, tbl[i].name);
  }

  exit();
}
