To compile, make sure that makefile, main.cpp, and cluster.cpp are in the 
same directory and type 'make' at the prompt.
To run the program, make sure the data files are in the same directory as 
the compiled main file and at the prompt type 'main' followed by a space 
then the data set followed by a space then the number of clusters followed 
by a space then finally the method.
Example:
'main data2.txt 3 kmeans'
Finds a clustering of three clusters by k-means on data set 2.

(Tested on linprog3)
