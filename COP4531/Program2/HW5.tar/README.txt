To compile, make sure that makefile, interval.cpp, and lcs.cpp are in 
the same directory and type 'make' at the prompt.
To run the program, make sure the data files are in the same directory as 
the compiled files and at the prompt type 'interval' or 'lcs' followed 
by a space then the data set(data1.txt for interval and data2.txt for 
lcs).
Example:
'lcs data2.txt'

(Tested on linprog4)
