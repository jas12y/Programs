package com.example.project1;

import java.util.Random;

import org.w3c.dom.Text;

import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBar;
import android.support.v4.app.Fragment;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Build;

public class MainActivity extends ActionBarActivity {

	int round, click;
	Random rand = new Random();
	int arr[] = new int [25];
	TextView tv3;
	String move;
	Button play;
	Button btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9;

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		if (savedInstanceState == null) {
			getSupportFragmentManager().beginTransaction()
					.add(R.id.container, new PlaceholderFragment()).commit();
		}

		btn1 = (Button)findViewById(R.id.button1);
		btn2 = (Button)findViewById(R.id.button2);
		btn3 = (Button)findViewById(R.id.button3);
		btn4 = (Button)findViewById(R.id.button4);
		btn5 = (Button)findViewById(R.id.button5);
		btn6 = (Button)findViewById(R.id.button6);
		btn7 = (Button)findViewById(R.id.button7);
		btn8 = (Button)findViewById(R.id.button8);
		btn9 = (Button)findViewById(R.id.button9);
		tv3 = (TextView)findViewById(R.id.textView3);
		play = (Button)findViewById(R.id.playbtn);
		play.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				round = 0;
				click = 0;
				move = "LEVEL " + round;
				Challange();
				play.setText("start over");
				tv3.setText(move);
				Show(0);
			}
		});
				btn1.setOnClickListener(new OnClickListener()
				{
					@Override
					public void onClick(View v)
					{
						Check(1);
					}
				});
				btn2.setOnClickListener(new OnClickListener()
				{
					@Override
					public void onClick(View v)
					{
						Check(2);
					}
				});
				btn3.setOnClickListener(new OnClickListener()
				{
					@Override
					public void onClick(View v)
					{
						Check(3);
					}
				});
				btn4.setOnClickListener(new OnClickListener()
				{
					@Override
					public void onClick(View v)
					{
						Check(4);
					}
				});
				btn5.setOnClickListener(new OnClickListener()
				{
					@Override
					public void onClick(View v)
					{
						Check(5);
					}
				});
				btn6.setOnClickListener(new OnClickListener()
				{
					@Override
					public void onClick(View v)
					{
						Check(6);
					}
				});
				btn7.setOnClickListener(new OnClickListener()
				{
					@Override
					public void onClick(View v)
					{
						Check(7);
					}
				});
				btn8.setOnClickListener(new OnClickListener()
				{
					@Override
					public void onClick(View v)
					{
						Check(8);
					}
				});
				btn9.setOnClickListener(new OnClickListener()
				{
					@Override
					public void onClick(View v)
					{
						Check(9);
					}
				});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	public void Challange()
	{
		int next;
		for(int i = 0; i < 25; ++i)
		{
			next = rand.nextInt(9) + 1;
			arr[i] = next;
		}
	}

	public void Show(int n)
	{
		int delay = 1000;
		
		Handler handler = new Handler();
		for(int i = 0; i <= n; ++i)
		{
			final int num = arr[i];
			handler.postDelayed(new Runnable()
			{ 
				public void run()
				{
					Display(num);
				}
			}, delay*i);
		}
	}
	
	public void Display(final int next)
	{
		Handler handler = new Handler();
		switch(next)
		{
			case 1:
				final Drawable b1 = btn1.getBackground();
				btn1.setBackgroundColor(getResources().getColor(R.color.garnet));
				handler.postDelayed(new Runnable()
				{ 
					public void run()
					{ 
						btn1.setBackground(b1);
					} 
				}, 200);
				break;
			case 2:
				final Drawable b2 = btn2.getBackground();
				btn2.setBackgroundColor(getResources().getColor(R.color.garnet));
				handler.postDelayed(new Runnable()
				{ 
					public void run()
					{ 
						btn2.setBackground(b2);
					} 
				}, 200);
				break;
			case 3:
				final Drawable b3 = btn3.getBackground();
				btn3.setBackgroundColor(getResources().getColor(R.color.garnet));
				handler.postDelayed(new Runnable()
				{ 
					public void run()
					{ 
						btn3.setBackground(b3);
					} 
				}, 200);
				break;
			case 4:
				final Drawable b4 = btn4.getBackground();
				btn4.setBackgroundColor(getResources().getColor(R.color.garnet));
				handler.postDelayed(new Runnable()
				{ 
					public void run()
					{ 
						btn4.setBackground(b4);
					} 
				}, 200);
				break;
			case 5:
				final Drawable b5 = btn5.getBackground();
				btn5.setBackgroundColor(getResources().getColor(R.color.garnet));
				handler.postDelayed(new Runnable()
				{ 
					public void run()
					{ 
						btn5.setBackground(b5);
					} 
				}, 200);
				break;
			case 6:
				final Drawable b6 = btn6.getBackground();
				btn6.setBackgroundColor(getResources().getColor(R.color.garnet));
				handler.postDelayed(new Runnable()
				{ 
					public void run()
					{ 
						btn6.setBackground(b6);
					} 
				}, 200);
				break;
			case 7:
				final Drawable b7 = btn7.getBackground();
				btn7.setBackgroundColor(getResources().getColor(R.color.garnet));
				handler.postDelayed(new Runnable()
				{ 
					public void run()
					{ 
						btn7.setBackground(b7);
					} 
				}, 200);
				break;
			case 8:
				final Drawable b8 = btn8.getBackground();
				btn8.setBackgroundColor(getResources().getColor(R.color.garnet));
				handler.postDelayed(new Runnable()
				{ 
					public void run()
					{ 
						btn8.setBackground(b8);
					} 
				}, 200);
				break;
			case 9:
				final Drawable b9 = btn9.getBackground();
				btn9.setBackgroundColor(getResources().getColor(R.color.garnet));
				handler.postDelayed(new Runnable()
				{ 
					public void run()
					{ 
						btn9.setBackground(b9);
					} 
				}, 200);
				break;
		}
	}

	public void Check(int n)
	{
		if(click <= round)
		{
			if(arr[click] != n)
			{
				play.setText("play again");
				Toast.makeText(getApplicationContext(), "You Lose!", Toast.LENGTH_SHORT).show();
				return;
			}
			if(click == round)
			{
				++round;
				click = 0;
				move = "LEVEL " + round;
				tv3.setText(move);
				Show(round);
				return;
			}
		}
		++click;
	}
	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_main, container,
					false);
			return rootView;
		}
	}

}
